public class Main {
    public static void main(String[] args) {
        Engine newGame = new Engine();
        newGame.printGame();
    }
}
