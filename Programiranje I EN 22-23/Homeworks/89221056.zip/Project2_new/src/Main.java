public class Main {
    public static void main(String[] args) {
        StartingFrame newGame = new StartingFrame();
    }
}
