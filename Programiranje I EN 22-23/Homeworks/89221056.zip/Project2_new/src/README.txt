The game starts from Main.java

Hierarchy of java classes:
    - Main
    - StartingFrame
    - ConfigFrame
    - GameEngine

    Buttons, Labels, Menu, MenuBar and Panels are classes used for creating the widgets.

To run the game, run only Main.java