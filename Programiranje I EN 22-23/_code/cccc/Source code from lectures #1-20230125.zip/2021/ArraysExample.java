package prog1_en_1;

public class ArraysExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int firstArray[];
		firstArray = new int[1000000];
		firstArray[88] = 88;
		firstArray[11] = 7;
		firstArray[22] = firstArray[11];
		int this2DArray[][];
		int y = 19;
		
		if(y > (y = 19)) {
			System.out.println("EQUAL");
		}
		else {
			System.out.println("NOT");
		}
	}

}
