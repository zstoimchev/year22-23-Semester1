package prog1_en_1;

public class Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x;
		int y;
		x = 5;
		y = 77;
		System.out.println("X: " + x + ", Y: " + y);
		System.out.println(x + y);
		System.out.println("The result is:" + x + y);
		System.out.println("The result is:" + (x + y));
		
		int testNumber = 2000000000;
		testNumber = testNumber * 2;
		System.out.println(testNumber);
	}

}
