package prog1_en_1;

class Banana {
	public static void main(String[] args) {
		int[] nr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		for (int i : nr) {
			System.out.println(" Current number is: " + i);
		}
		
		while(true) {
			System.out.println("banana");
		}
	}
}