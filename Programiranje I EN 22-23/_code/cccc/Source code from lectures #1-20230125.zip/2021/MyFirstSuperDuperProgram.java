package prog1_en_1;
/*
 * 
 *  rzmevjiočltr ehji6elvkjh,mr 
 *  
 *  
 *  */
public class MyFirstSuperDuperProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello!");  //say hello to the user
	}

}
