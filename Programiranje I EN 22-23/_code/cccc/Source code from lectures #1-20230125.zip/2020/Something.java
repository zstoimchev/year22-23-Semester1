
public class Something {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello!!!");
	}

}


int 1, 2, 77, -77777
32 bits of data: 2 to the poser of 32 different values

bit = the smallest part of information 1/0, jey/no,black/white, true/false

1 2 values (0 and 1)
2 bits 11, 10, 01, 00
2 111, 110, 101, .... 000 2^3 = 8


32 bits = 2^32 

2,4,8,16,32,64,128,256,512,1024
2^10 = 1024
2^20 = 1000*1000 = 1million
2^30 = 1000 millions , 10^9
4 1000 millions or 4*10^9
+- 2billion values 


Floating point numbers:
	15.19
	
	
	
Operators
	
1+3*4 
a + 2
x++

Bool akgebra

true/false
0/1
&&, ||, !


0/1  0/1

x y  	00 01 10 11
x && y   0  0  0  1

x y  	00 01 10 11
x || y   0  1  1  1

x   	0 1
!x      1 0


(a > b) && (a < b)

int age;

if(age > 10) && (age < 20)  //teen

Functions

int f(int x) { 3 * x + 4}
























