
public class Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10000;
		int b;
		b = a;
		System.out.println(b);
		
		float f;
		f = (float)1.1;
		System.out.println(f);
		String name;
		name = "Jernej";
		System.out.println(name);
		
		byte bbb = +127
				
				
				;
		
		
	}

}
