
public class Endless {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		for(;;) {
			System.out.println("Step number: " + i++);
		}
	}

}
