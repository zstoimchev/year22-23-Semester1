
public class StdINOUT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Good output");
		System.err.println("Bad output");
	}

}
