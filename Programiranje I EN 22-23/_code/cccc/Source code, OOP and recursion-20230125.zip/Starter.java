
public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square sq = new Square(4);
		//sq.a = 4;
		sq.draw();
		Cube cube = new Cube(5);
		//cube.a = 5;
		cube.draw();
	}

}
