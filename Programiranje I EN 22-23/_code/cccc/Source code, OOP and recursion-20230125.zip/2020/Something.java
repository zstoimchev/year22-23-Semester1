
public interface Something {
	int myFirstMethod();
	String mySecondMethod(int h);
}
