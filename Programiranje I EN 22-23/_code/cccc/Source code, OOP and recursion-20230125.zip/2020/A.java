
public class A implements Something, SomethingElse{
	int a;
	public int myFirstMethod() {
		return 888;
	}
	public String mySecondMethod(int h) {
		return("Banana");
	}
	public int elseMethod() {
		return(888888);
	}
}
