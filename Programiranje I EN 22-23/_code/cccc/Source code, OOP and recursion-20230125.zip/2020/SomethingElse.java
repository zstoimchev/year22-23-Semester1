
public interface SomethingElse {
	int elseMethod();
}
