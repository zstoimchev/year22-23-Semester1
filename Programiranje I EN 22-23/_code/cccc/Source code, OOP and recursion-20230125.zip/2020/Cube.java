
public class Cube extends Square{
	void draw () {
		super.draw();
		System.out.println("I am a cube");
	}
	void draw (int side) {
		super.draw();
		System.out.println("I am a cube");
	}
	void draw1() {
		System.out.println("I am method 1");
	}
	
}
