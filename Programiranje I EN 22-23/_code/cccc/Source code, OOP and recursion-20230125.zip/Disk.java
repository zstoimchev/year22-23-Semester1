
public class Disk implements IDisk {

	@Override
	public boolean write(String fileName, String data) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String read(String fileName) {
		// TODO Auto-generated method stub
		return null;
	}

}
