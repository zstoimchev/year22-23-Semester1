
public class FirstString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String haha = "banana";
		System.out.println(haha.substring(0, 3));
	}

}
