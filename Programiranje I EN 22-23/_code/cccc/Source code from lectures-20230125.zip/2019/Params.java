
public class Params {
	static int sum(int a, int b) {
		a = a + 1;
		return(a + b);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 8;
		int y = 9;
		int h = sum(x, y);
		System.out.println(h);
	}

}
