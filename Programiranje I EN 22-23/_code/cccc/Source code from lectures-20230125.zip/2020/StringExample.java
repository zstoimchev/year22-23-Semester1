
public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String aaa = "Banana is a fruit.";
		System.out.println(aaa.charAt(0));
		for(int i = 0; i < aaa.length(); i++) {
			System.out.println(aaa.charAt(i));
		}
	}

	/*
	palindrome ... emordnilap
	pericarežeracirep
	*/
}
