import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Input two numbers: ");
		int one = sc.nextInt();
		int two = sc.nextInt();
		System.out.println(one * two);
	}

}
