
public class C {
	int value;
}
