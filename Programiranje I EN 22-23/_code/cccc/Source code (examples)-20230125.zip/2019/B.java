
public class B {
	void something() {
		A ss = new A();
		ss.a = 9;
		ss.value = 11;
	}
}
