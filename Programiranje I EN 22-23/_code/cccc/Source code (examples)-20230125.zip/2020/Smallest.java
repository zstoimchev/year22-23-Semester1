
public class Smallest {

}
