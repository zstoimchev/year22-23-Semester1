
public class Stars {
	public static void main(String aaa[]) {
		int a = 4;
		for(int i = 0; i < a; i++) {
			for(int j = 0; j < a; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
