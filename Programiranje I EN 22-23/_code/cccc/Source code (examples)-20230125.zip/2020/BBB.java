
public class BBB {
	public int value;
}
