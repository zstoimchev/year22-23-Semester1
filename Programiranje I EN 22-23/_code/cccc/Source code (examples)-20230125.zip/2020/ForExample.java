
public class ForExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {1,5 , 7, 9, 11, 16};
		for(int i = 0; i < a.length; i++) {
			System.out.println(a[i] + " " + a.length);
		}
	}

}
