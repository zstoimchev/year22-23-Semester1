package prog1_en_3;

public class Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		String aaa = "123";
		int i = Integer.parseInt(aaa);
		System.out.println(aaa + 1);
		System.out.println(i + 1);
	}

}
