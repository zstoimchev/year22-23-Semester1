package prog1_en_3;

public class A {
	int value;
}
