package prog1_en_3;

public class ClassExample {
	static class B{
		int myBvalue;
	}
	
	void print(){
		B jj = new B();
		jj.myBvalue = 9;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassExample cc = new ClassExample();
		B jj = new B();
		double x = 1.9;
		int y;
		y = (int) x;
		
		
	}

}
