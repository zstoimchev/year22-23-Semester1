
public class Node {
	String name;
	public Node(String ii){
	    name = ii;
	  }
}
