public class Vozel {
  String ime = "";
  public Vozel(String ii){
    ime = ii;
  }
}