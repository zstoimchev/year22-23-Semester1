
public class B extends A{
	int aa() {
		return 16;
	}
}
