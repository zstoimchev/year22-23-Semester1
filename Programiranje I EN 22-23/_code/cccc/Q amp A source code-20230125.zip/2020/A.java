
public abstract class A {
	abstract int aa();
	int a;
	int aaa() {
		return 17;
	}
}
