
public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//A example = new A();
		B example = new B();
		System.out.println(example.aa());
	}

}
