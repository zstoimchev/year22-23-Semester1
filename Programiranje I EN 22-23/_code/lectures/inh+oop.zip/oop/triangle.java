public class triangle {
    Side AC;
    Point D;

    public Triangle(Side AC, Point b){
        this.AC=    AC;
        B=b;
        this.AB=new Side(AC.a.new Point(AC.B.getx()), AC.A.gety());
    }
}
//.lost it at 10.o7
