public class Side {
    Point A;
    Point B;

    public Side(Point a, Point b){
        A=a;
        B=b;
    }
    
}
