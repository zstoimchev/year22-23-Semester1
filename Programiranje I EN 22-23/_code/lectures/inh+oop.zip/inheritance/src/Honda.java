public class Honda extends Vehicle{

    public Honda(int numTires, String color, double topSpeed) {
        super(numTires, color, topSpeed);
    }

    /*@Override
    public void drive(){
        System.out.println("tutututu");
    }*/

    @Override
    public void drive(){
        System.out.println("hondaaaaz");
    }


}
