public interface Drivable {

    public void drive();
}
