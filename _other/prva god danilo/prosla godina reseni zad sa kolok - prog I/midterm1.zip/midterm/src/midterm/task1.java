package midterm;
import java.util.*;
public class task1 {
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Insert first number: ");
		int n = scan.nextInt();
		System.out.print("Insert second number: ");
		int m = scan.nextInt();
		int difference = 0;
		difference = n*n - m*m;
		System.out.print("Difference of the squares of these two numbers is: " + difference);
		scan.close();
	}
}
